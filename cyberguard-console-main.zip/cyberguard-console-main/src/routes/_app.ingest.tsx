import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/soc/PageHeader";
import { Btn } from "@/components/soc/Btn";
import { Database, UploadCloud, Check } from "lucide-react";

export const Route = createFileRoute("/_app/ingest")({
  head: () => ({ meta: [{ title: "Log Ingestion — SentinelAI" }] }),
  component: IngestPage,
});

const SOURCES = [
  { name: "Syslog (UDP/514)", desc: "Generic UNIX/network device logs", live: true },
  { name: "AWS CloudTrail", desc: "Multi-account audit events via S3 → SQS", live: true },
  { name: "Microsoft 365", desc: "Audit log via Graph API", live: false },
  { name: "Kubernetes", desc: "Cluster audit + pod logs via Fluent Bit", live: true },
  { name: "Suricata", desc: "EVE JSON via Filebeat", live: true },
];

function IngestPage() {
  const [json, setJson] = useState('{"event":"login","user":"alice","src_ip":"10.0.0.4"}');
  const [sent, setSent] = useState(false);

  function send() {
    try {
      JSON.parse(json);
      setSent(true);
      setTimeout(() => setSent(false), 2000);
    } catch {
      alert("Invalid JSON");
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Detection" title="Log Ingestion" description="Connected sources and ad-hoc log push for testing detections." />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2 grid gap-3">
          {SOURCES.map((s) => (
            <div key={s.name} className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 shadow-card">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary"><Database className="h-5 w-5" /></div>
              <div className="min-w-0 flex-1">
                <div className="font-medium">{s.name}</div>
                <div className="text-xs text-muted-foreground">{s.desc}</div>
              </div>
              <span className={`flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] ${s.live ? "border-success/30 bg-success/10 text-success" : "border-border bg-muted text-muted-foreground"}`}>
                <span className={`h-1.5 w-1.5 rounded-full ${s.live ? "bg-success animate-pulse" : "bg-muted-foreground"}`} />
                {s.live ? "Live" : "Idle"}
              </span>
            </div>
          ))}
        </div>

        <div className="rounded-xl border border-border bg-card p-4 shadow-card">
          <div className="mb-2 flex items-center gap-2 text-sm font-semibold"><UploadCloud className="h-4 w-4 text-primary" /> Send test event</div>
          <textarea
            value={json} onChange={(e) => setJson(e.target.value)} rows={8}
            className="w-full rounded-md border border-border bg-background p-3 font-mono text-xs focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />
          <Btn variant="hero" size="sm" className="mt-2 w-full" onClick={send}>
            {sent ? <><Check className="h-4 w-4" /> Sent to /ingest</> : <>Send to /ingest</>}
          </Btn>
        </div>
      </div>
    </div>
  );
}
