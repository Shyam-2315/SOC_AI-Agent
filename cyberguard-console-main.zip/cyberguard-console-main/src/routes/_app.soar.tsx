import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/soc/PageHeader";
import { Btn } from "@/components/soc/Btn";
import { StatusBadge } from "@/components/soc/SeverityBadge";
import { MOCK } from "@/lib/mock";
import { Ban, Play } from "lucide-react";

export const Route = createFileRoute("/_app/soar")({
  head: () => ({ meta: [{ title: "SOAR — SentinelAI" }] }),
  component: SoarPage,
});

const PLAYBOOKS = [
  { id: "P-Block-C2", name: "Block C2 IP", desc: "Push deny rule to edge firewall and EDR.", actions: 4 },
  { id: "P-Isolate-Host", name: "Isolate compromised host", desc: "Quarantine via EDR and revoke session tokens.", actions: 6 },
  { id: "P-Account-Lockdown", name: "Account lockdown", desc: "Disable user, force MFA reset, kill sessions.", actions: 5 },
];

function SoarPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Response"
        title="SOAR Actions"
        description="Automated and analyst-driven response across the estate."
        actions={<Btn variant="hero" size="sm"><Play className="h-4 w-4" /> Run playbook</Btn>}
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2 overflow-hidden rounded-xl border border-border bg-card shadow-card">
          <div className="border-b border-border px-5 py-3 text-sm font-semibold">Recent actions</div>
          <div className="scrollbar-thin overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-background/30 text-left text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Action</th>
                  <th className="px-4 py-3 font-medium">Target</th>
                  <th className="px-4 py-3 font-medium">Playbook</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">When</th>
                </tr>
              </thead>
              <tbody>
                {MOCK.soar.map((a) => (
                  <tr key={a.id} className="border-t border-border/60 hover:bg-accent/40">
                    <td className="px-4 py-3 font-medium">{a.name}</td>
                    <td className="px-4 py-3 font-mono text-xs">{a.target}</td>
                    <td className="px-4 py-3 font-mono text-xs text-primary">{a.playbook}</td>
                    <td className="px-4 py-3"><StatusBadge status={a.status} /></td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{new Date(a.timestamp).toLocaleTimeString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card shadow-card">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <div className="text-sm font-semibold">Blocked IPs</div>
            <span className="text-xs text-muted-foreground">{MOCK.blockedIps.length}</span>
          </div>
          <ul className="divide-y divide-border">
            {MOCK.blockedIps.map((ip) => (
              <li key={ip} className="flex items-center justify-between px-5 py-3">
                <div className="flex items-center gap-2">
                  <Ban className="h-4 w-4 text-destructive" />
                  <span className="font-mono text-sm">{ip}</span>
                </div>
                <button className="text-xs text-muted-foreground hover:text-foreground">Unblock</button>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div>
        <div className="mb-3 text-sm font-semibold">Playbooks</div>
        <div className="grid gap-4 md:grid-cols-3">
          {PLAYBOOKS.map((p) => (
            <div key={p.id} className="rounded-xl border border-border bg-card p-5 shadow-card transition hover:border-primary/40">
              <div className="flex items-center justify-between">
                <div className="text-sm font-semibold">{p.name}</div>
                <span className="rounded-full border border-border px-2 py-0.5 text-[10px] text-muted-foreground">{p.actions} steps</span>
              </div>
              <div className="mt-1 font-mono text-xs text-muted-foreground">{p.id}</div>
              <p className="mt-3 text-sm text-muted-foreground">{p.desc}</p>
              <div className="mt-4 flex gap-2">
                <Btn size="sm" variant="primary"><Play className="h-3.5 w-3.5" /> Run</Btn>
                <Btn size="sm" variant="outline">Edit</Btn>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
