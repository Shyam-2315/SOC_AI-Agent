import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/soc/PageHeader";
import { SeverityBadge, StatusBadge } from "@/components/soc/SeverityBadge";
import { Btn } from "@/components/soc/Btn";
import { MOCK } from "@/lib/mock";

export const Route = createFileRoute("/_app/incidents")({
  head: () => ({ meta: [{ title: "Incidents — SentinelAI" }] }),
  component: IncidentsPage,
});

const STATUSES = ["open", "investigating", "resolved", "closed"] as const;
type Status = typeof STATUSES[number];

function IncidentsPage() {
  const [items, setItems] = useState(MOCK.incidents);
  const [filter, setFilter] = useState<Status | "all">("all");

  const visible = filter === "all" ? items : items.filter((i) => i.status === filter);

  function update(id: string, status: Status) {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, status } : i)));
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Operations"
        title="Incidents"
        description="Investigations linking related alerts, owners and response actions."
        actions={<Btn variant="hero" size="sm">+ New incident</Btn>}
      />
      <div className="flex flex-wrap gap-2">
        {(["all", ...STATUSES] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`rounded-md border px-3 py-1.5 text-xs capitalize transition ${
              filter === s ? "border-primary bg-primary/10 text-primary" : "border-border bg-card text-muted-foreground hover:text-foreground"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {visible.map((i) => (
          <div key={i.id} className="flex flex-col rounded-xl border border-border bg-card p-5 shadow-card transition hover:border-primary/40">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-mono text-muted-foreground">{i.id}</div>
                <div className="mt-1 text-base font-semibold">{i.title}</div>
              </div>
              <SeverityBadge severity={i.severity} />
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
              <div>
                <div className="text-muted-foreground">Status</div>
                <div className="mt-1"><StatusBadge status={i.status} /></div>
              </div>
              <div>
                <div className="text-muted-foreground">Analyst</div>
                <div className="mt-1 font-medium">{i.analyst}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Linked alert</div>
                <div className="mt-1 font-mono text-primary">{i.alertId}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Updated</div>
                <div className="mt-1">{new Date(i.updatedAt).toLocaleString()}</div>
              </div>
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-border pt-3">
              <span className="text-xs text-muted-foreground">Set status:</span>
              {STATUSES.map((s) => (
                <button
                  key={s}
                  onClick={() => update(i.id, s)}
                  className={`rounded-md border px-2 py-1 text-[11px] capitalize transition ${
                    i.status === s ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
