import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/soc/PageHeader";
import { Btn } from "@/components/soc/Btn";
import { StatusBadge } from "@/components/soc/SeverityBadge";
import { MOCK } from "@/lib/mock";
import { Copy, Check, Plus, Trash2 } from "lucide-react";

export const Route = createFileRoute("/_app/collectors")({
  head: () => ({ meta: [{ title: "Collectors — SentinelAI" }] }),
  component: CollectorsPage,
});

type C = (typeof MOCK.collectors)[number] & { enabled?: boolean };

function CollectorsPage() {
  const [items, setItems] = useState<C[]>(MOCK.collectors.map((c) => ({ ...c, enabled: c.status === "online" })));
  const [name, setName] = useState("");
  const [token, setToken] = useState<{ name: string; token: string } | null>(null);
  const [copied, setCopied] = useState(false);

  function create() {
    if (!name.trim()) return;
    const id = `c-${Date.now()}`;
    const t = `sk_live_${Math.random().toString(36).slice(2, 10)}${Math.random().toString(36).slice(2, 10)}`;
    setItems((p) => [...p, { id, name, status: "offline", lastSeen: new Date().toISOString(), kind: "custom", enabled: true }]);
    setToken({ name, token: t });
    setName("");
  }
  function copy() {
    if (!token) return;
    navigator.clipboard.writeText(token.token);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }
  function toggle(id: string) {
    setItems((p) => p.map((c) => (c.id === id ? { ...c, enabled: !c.enabled } : c)));
  }
  function remove(id: string) {
    setItems((p) => p.filter((c) => c.id !== id));
  }

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Detection" title="Collectors" description="Telemetry sources feeding the detection engine." />

      <div className="rounded-xl border border-border bg-card p-4 shadow-card">
        <div className="flex flex-col gap-2 sm:flex-row">
          <input
            value={name} onChange={(e) => setName(e.target.value)} placeholder="Collector name (e.g. edge-fw-02)"
            className="flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />
          <Btn variant="hero" onClick={create}><Plus className="h-4 w-4" /> Create collector</Btn>
        </div>
        {token && (
          <div className="mt-3 rounded-md border border-warning/30 bg-warning/10 p-3 text-sm">
            <div className="text-xs font-semibold uppercase tracking-wider text-warning">One-time token for "{token.name}"</div>
            <div className="mt-1 text-xs text-muted-foreground">Copy this now — it will not be shown again.</div>
            <div className="mt-2 flex items-center gap-2">
              <code className="flex-1 truncate rounded bg-background px-3 py-2 font-mono text-xs">{token.token}</code>
              <Btn size="sm" variant="outline" onClick={copy}>{copied ? <><Check className="h-3.5 w-3.5" /> Copied</> : <><Copy className="h-3.5 w-3.5" /> Copy</>}</Btn>
            </div>
          </div>
        )}
      </div>

      <div className="grid gap-3">
        {items.map((c) => (
          <div key={c.id} className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 shadow-card">
            <div>
              <div className="font-medium">{c.name}</div>
              <div className="text-xs text-muted-foreground">{c.kind} · last seen {new Date(c.lastSeen).toLocaleString()}</div>
            </div>
            <div className="ml-auto flex items-center gap-3">
              <StatusBadge status={c.status} />
              <button onClick={() => toggle(c.id)} className={`relative h-6 w-11 rounded-full border ${c.enabled ? "border-primary bg-primary/30" : "border-border bg-muted"}`}>
                <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-foreground transition ${c.enabled ? "left-6" : "left-0.5"}`} />
              </button>
              <Btn size="sm" variant="ghost" onClick={() => remove(c.id)} className="text-destructive hover:bg-destructive/10"><Trash2 className="h-4 w-4" /></Btn>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
