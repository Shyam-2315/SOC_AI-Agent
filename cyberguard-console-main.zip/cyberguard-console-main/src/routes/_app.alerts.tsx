import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/soc/PageHeader";
import { DataTable, type Column } from "@/components/soc/DataTable";
import { SeverityBadge } from "@/components/soc/SeverityBadge";
import { Btn } from "@/components/soc/Btn";
import { MOCK } from "@/lib/mock";
import { Download, Filter } from "lucide-react";

export const Route = createFileRoute("/_app/alerts")({
  head: () => ({ meta: [{ title: "Alerts — SentinelAI" }] }),
  component: AlertsPage,
});

type Alert = (typeof MOCK.alerts)[number];

function AlertsPage() {
  const cols: Column<Alert>[] = [
    { key: "sev", header: "Severity", render: (r) => <SeverityBadge severity={r.severity} /> },
    { key: "title", header: "Alert", render: (r) => <span className="font-medium">{r.title}</span> },
    { key: "mitre", header: "MITRE", render: (r) => <span className="font-mono text-xs text-muted-foreground">{r.mitre.tactic} · {r.mitre.technique}</span> },
    { key: "ip", header: "Source IP", render: (r) => <span className="font-mono text-xs">{r.ip}</span> },
    { key: "src", header: "Source", render: (r) => <span className="text-muted-foreground">{r.source}</span> },
    { key: "rule", header: "Rule", render: (r) => <span className="font-mono text-xs text-primary">{r.rule}</span> },
    { key: "ts", header: "Timestamp", render: (r) => <span className="text-xs text-muted-foreground">{new Date(r.timestamp).toLocaleString()}</span> },
  ];
  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Operations"
        title="Alerts"
        description="All detections across collectors and detection rules."
        actions={
          <>
            <Btn variant="outline" size="sm"><Filter className="h-4 w-4" /> Filter</Btn>
            <Btn variant="outline" size="sm"><Download className="h-4 w-4" /> Export</Btn>
          </>
        }
      />
      <DataTable rows={MOCK.alerts} columns={cols} searchPlaceholder="Search alerts, IPs, rules…" searchKeys={["title", "ip", "source", "rule"]} />
    </div>
  );
}
