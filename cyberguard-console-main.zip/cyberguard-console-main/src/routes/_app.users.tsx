import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/soc/PageHeader";
import { DataTable, type Column } from "@/components/soc/DataTable";
import { Btn } from "@/components/soc/Btn";
import { MOCK } from "@/lib/mock";

export const Route = createFileRoute("/_app/users")({
  head: () => ({ meta: [{ title: "Users — SentinelAI" }] }),
  component: UsersPage,
});

type User = (typeof MOCK.users)[number];

function UsersPage() {
  const cols: Column<User>[] = [
    { key: "name", header: "Name", render: (r) => (
      <div className="flex items-center gap-2">
        <div className="grid h-7 w-7 place-items-center rounded-full bg-gradient-primary text-xs font-semibold text-primary-foreground">{r.name[0]}</div>
        <span className="font-medium">{r.name}</span>
      </div>
    )},
    { key: "email", header: "Email", render: (r) => <span className="font-mono text-xs text-muted-foreground">{r.email}</span> },
    { key: "role", header: "Role", render: (r) => <span className="rounded-md border border-border px-2 py-0.5 text-xs">{r.role}</span> },
    { key: "actions", header: "", render: () => <Btn size="sm" variant="ghost">Edit</Btn>, className: "text-right" },
  ];
  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Workspace" title="Users" description="Members and roles in your organization." actions={<Btn variant="hero" size="sm">+ Invite user</Btn>} />
      <DataTable rows={MOCK.users} columns={cols} searchPlaceholder="Search users…" searchKeys={["name", "email", "role"]} />
    </div>
  );
}
