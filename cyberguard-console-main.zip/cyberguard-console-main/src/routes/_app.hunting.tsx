import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/soc/PageHeader";
import { Btn } from "@/components/soc/Btn";
import { Crosshair, Play, Search } from "lucide-react";
import { SeverityBadge } from "@/components/soc/SeverityBadge";
import { MOCK } from "@/lib/mock";
import { EmptyState } from "@/components/soc/States";

export const Route = createFileRoute("/_app/hunting")({
  head: () => ({ meta: [{ title: "Threat Hunting — SentinelAI" }] }),
  component: HuntingPage,
});

const PRESETS = [
  { name: "Lateral movement (SMB)", q: "event.proto:smb AND event.action:auth_failure" },
  { name: "Suspicious PowerShell", q: "process.name:powershell.exe AND process.cmd:*-EncodedCommand*" },
  { name: "TOR exits", q: "dest.ip in tor_exit_nodes" },
];

function HuntingPage() {
  const [q, setQ] = useState(PRESETS[0].q);
  const [ran, setRan] = useState(false);
  const results = ran ? MOCK.alerts.slice(0, 8) : [];

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Investigation" title="Threat Hunting" description="Pivot across telemetry with KQL-style queries and saved hunts." />

      <div className="rounded-xl border border-border bg-card p-4 shadow-card">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <textarea
            value={q} onChange={(e) => setQ(e.target.value)}
            rows={3}
            className="w-full resize-none rounded-md border border-border bg-background px-9 py-2.5 font-mono text-sm focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <Btn variant="hero" size="sm" onClick={() => setRan(true)}><Play className="h-3.5 w-3.5" /> Run hunt</Btn>
          <span className="text-xs text-muted-foreground">Presets:</span>
          {PRESETS.map((p) => (
            <button key={p.name} onClick={() => { setQ(p.q); setRan(false); }} className="rounded-md border border-border px-2 py-1 text-xs text-muted-foreground hover:border-primary/40 hover:text-foreground">{p.name}</button>
          ))}
        </div>
      </div>

      {results.length === 0 ? (
        <EmptyState icon={<Crosshair className="h-5 w-5" />} title="No hunt run yet" description="Choose a preset or write a query, then click Run hunt." />
      ) : (
        <div className="overflow-hidden rounded-xl border border-border bg-card shadow-card">
          <div className="border-b border-border px-5 py-3 text-sm font-semibold">Results · {results.length}</div>
          <ul className="divide-y divide-border">
            {results.map((r) => (
              <li key={r.id} className="flex items-center gap-3 px-5 py-3 hover:bg-accent/40">
                <SeverityBadge severity={r.severity} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">{r.title}</div>
                  <div className="font-mono text-xs text-muted-foreground">{r.mitre.tactic} · {r.ip}</div>
                </div>
                <div className="text-xs text-muted-foreground">{new Date(r.timestamp).toLocaleString()}</div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
