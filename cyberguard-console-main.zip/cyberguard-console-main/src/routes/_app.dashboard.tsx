import { createFileRoute } from "@tanstack/react-router";
import { Bell, AlertOctagon, Zap, Radio, Activity, ShieldCheck, ArrowRight } from "lucide-react";
import { StatCard } from "@/components/soc/StatCard";
import { PageHeader } from "@/components/soc/PageHeader";
import { SeverityBadge, StatusBadge } from "@/components/soc/SeverityBadge";
import { MOCK } from "@/lib/mock";
import { Link } from "@tanstack/react-router";
import { Btn } from "@/components/soc/Btn";

export const Route = createFileRoute("/_app/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — SentinelAI" }] }),
  component: Dashboard,
});

function Dashboard() {
  const s = MOCK.stats;
  const max = Math.max(...MOCK.mitreTactics.map((t) => t.count));
  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Operations"
        title="SOC Overview"
        description="Live posture across detections, incidents and automated response."
        actions={<Link to="/hunting"><Btn variant="outline" size="sm">Start hunt <ArrowRight className="h-4 w-4" /></Btn></Link>}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Total alerts" value={s.totalAlerts.toLocaleString()} hint="last 24h" icon={<Bell className="h-4 w-4" />} accent="primary" />
        <StatCard label="Critical" value={s.criticalAlerts} hint="needs review" icon={<ShieldCheck className="h-4 w-4" />} accent="critical" />
        <StatCard label="Open incidents" value={s.openIncidents} hint="active" icon={<AlertOctagon className="h-4 w-4" />} accent="warning" />
        <StatCard label="SOAR actions" value={s.soarActions} hint="executed today" icon={<Zap className="h-4 w-4" />} accent="info" />
        <StatCard label="Collectors" value={`${s.collectorsOnline}/${s.collectorsTotal}`} hint="online" icon={<Radio className="h-4 w-4" />} accent="success" />
        <StatCard label="Realtime" value="Connected" hint="ws://stream" icon={<Activity className="h-4 w-4" />} accent="success" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-xl border border-border bg-card shadow-card">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <div className="text-sm font-semibold">Recent alerts</div>
            <Link to="/alerts" className="text-xs text-primary hover:underline">View all →</Link>
          </div>
          <ul className="divide-y divide-border">
            {MOCK.alerts.slice(0, 6).map((a) => (
              <li key={a.id} className="flex items-center gap-3 px-5 py-3 hover:bg-accent/40">
                <SeverityBadge severity={a.severity} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">{a.title}</div>
                  <div className="text-xs text-muted-foreground font-mono">{a.mitre.tactic} · {a.mitre.technique} · {a.ip}</div>
                </div>
                <div className="text-xs text-muted-foreground">{new Date(a.timestamp).toLocaleTimeString()}</div>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-xl border border-border bg-card shadow-card">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <div className="text-sm font-semibold">Open incidents</div>
            <Link to="/incidents" className="text-xs text-primary hover:underline">View all →</Link>
          </div>
          <ul className="divide-y divide-border">
            {MOCK.incidents.slice(0, 5).map((i) => (
              <li key={i.id} className="px-5 py-3 hover:bg-accent/40">
                <div className="flex items-center justify-between gap-2">
                  <div className="text-sm font-medium truncate">{i.title}</div>
                  <SeverityBadge severity={i.severity} />
                </div>
                <div className="mt-1 flex items-center justify-between text-xs text-muted-foreground">
                  <span>{i.analyst}</span>
                  <StatusBadge status={i.status} />
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-xl border border-border bg-card p-5 shadow-card">
          <div className="mb-4 flex items-center justify-between">
            <div className="text-sm font-semibold">MITRE ATT&CK tactics (24h)</div>
            <span className="text-xs text-muted-foreground">{MOCK.mitreTactics.reduce((a, b) => a + b.count, 0)} detections</span>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {MOCK.mitreTactics.map((t) => (
              <div key={t.name} className="rounded-lg border border-border bg-background/50 p-3">
                <div className="text-xs text-muted-foreground">{t.name}</div>
                <div className="mt-1 flex items-end justify-between">
                  <div className="text-xl font-semibold tabular-nums">{t.count}</div>
                  <div className="h-1.5 w-16 overflow-hidden rounded bg-border">
                    <div className="h-full bg-gradient-primary" style={{ width: `${(t.count / max) * 100}%` }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card shadow-card">
          <div className="border-b border-border px-5 py-3 text-sm font-semibold">Threat campaigns</div>
          <ul className="divide-y divide-border">
            {MOCK.campaigns.map((c) => (
              <li key={c.id} className="px-5 py-3">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <div className="text-sm font-medium">{c.name}</div>
                    <div className="text-xs text-muted-foreground">Actor: {c.actor} · {c.iocs} IOCs</div>
                  </div>
                  <SeverityBadge severity={c.severity} />
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
