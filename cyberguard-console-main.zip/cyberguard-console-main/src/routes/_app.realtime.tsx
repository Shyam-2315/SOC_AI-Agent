import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/soc/PageHeader";
import { SeverityBadge, StatusBadge } from "@/components/soc/SeverityBadge";
import { MOCK } from "@/lib/mock";
import { Activity, Zap } from "lucide-react";

export const Route = createFileRoute("/_app/realtime")({
  head: () => ({ meta: [{ title: "Realtime — SentinelAI" }] }),
  component: RealtimePage,
});

type Stream<T> = { items: T[] };

function RealtimePage() {
  const [connected, setConnected] = useState(true);
  const [alerts, setAlerts] = useState<Stream<typeof MOCK.alerts[number]>>({ items: MOCK.alerts.slice(0, 8) });
  const [actions, setActions] = useState<Stream<typeof MOCK.soar[number]>>({ items: MOCK.soar.slice(0, 6) });

  useEffect(() => {
    if (!connected) return;
    const t = setInterval(() => {
      const a = MOCK.alerts[Math.floor(Math.random() * MOCK.alerts.length)];
      const s = MOCK.soar[Math.floor(Math.random() * MOCK.soar.length)];
      setAlerts((p) => ({ items: [{ ...a, id: `a-${Date.now()}`, timestamp: new Date().toISOString() }, ...p.items].slice(0, 12) }));
      setActions((p) => ({ items: [{ ...s, id: `act-${Date.now()}`, timestamp: new Date().toISOString() }, ...p.items].slice(0, 12) }));
    }, 2500);
    return () => clearInterval(t);
  }, [connected]);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Operations"
        title="Realtime Feed"
        description="Live websocket stream of detections and response actions."
        actions={
          <button
            onClick={() => setConnected((v) => !v)}
            className={`flex items-center gap-2 rounded-md border px-3 py-1.5 text-xs ${connected ? "border-success/30 bg-success/10 text-success" : "border-border bg-card text-muted-foreground"}`}
          >
            <span className={`h-1.5 w-1.5 rounded-full ${connected ? "bg-success animate-pulse" : "bg-muted-foreground"}`} />
            {connected ? "Connected" : "Disconnected"}
          </button>
        }
      />
      <div className="grid gap-4 lg:grid-cols-2">
        <Stream title="Alert stream" icon={<Activity className="h-4 w-4 text-primary" />}>
          {alerts.items.map((a) => (
            <li key={a.id} className="flex items-center gap-3 px-5 py-3 hover:bg-accent/40 animate-in fade-in slide-in-from-top-1">
              <SeverityBadge severity={a.severity} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium">{a.title}</div>
                <div className="font-mono text-xs text-muted-foreground">{a.ip} · {a.mitre.technique}</div>
              </div>
              <div className="text-xs text-muted-foreground">{new Date(a.timestamp).toLocaleTimeString()}</div>
            </li>
          ))}
        </Stream>
        <Stream title="SOAR action stream" icon={<Zap className="h-4 w-4 text-primary" />}>
          {actions.items.map((a) => (
            <li key={a.id} className="flex items-center gap-3 px-5 py-3 hover:bg-accent/40 animate-in fade-in slide-in-from-top-1">
              <StatusBadge status={a.status} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium">{a.name}</div>
                <div className="font-mono text-xs text-muted-foreground">{a.target} · {a.playbook}</div>
              </div>
              <div className="text-xs text-muted-foreground">{new Date(a.timestamp).toLocaleTimeString()}</div>
            </li>
          ))}
        </Stream>
      </div>
    </div>
  );
}

function Stream({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card shadow-card">
      <div className="flex items-center gap-2 border-b border-border px-5 py-3">
        {icon}
        <div className="text-sm font-semibold">{title}</div>
      </div>
      <ul className="scrollbar-thin max-h-[60vh] divide-y divide-border overflow-y-auto">{children}</ul>
    </div>
  );
}
