import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/soc/PageHeader";
import { MOCK } from "@/lib/mock";
import { Building2 } from "lucide-react";
import { Btn } from "@/components/soc/Btn";

export const Route = createFileRoute("/_app/orgs")({
  head: () => ({ meta: [{ title: "Organizations — SentinelAI" }] }),
  component: OrgsPage,
});

function OrgsPage() {
  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Workspace" title="Organizations" description="Tenants managed by your account." actions={<Btn variant="hero" size="sm">+ New organization</Btn>} />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {MOCK.orgs.map((o) => (
          <div key={o.id} className="rounded-xl border border-border bg-card p-5 shadow-card transition hover:border-primary/40">
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-primary text-primary-foreground"><Building2 className="h-5 w-5" /></div>
              <div>
                <div className="font-semibold">{o.name}</div>
                <div className="text-xs text-muted-foreground">{o.plan}</div>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <div><div className="text-muted-foreground text-xs">Users</div><div className="font-medium">{o.users}</div></div>
              <div><div className="text-muted-foreground text-xs">Status</div><div className="font-medium text-success">Active</div></div>
            </div>
            <div className="mt-4 flex gap-2"><Btn variant="outline" size="sm">Manage</Btn><Btn variant="ghost" size="sm">Switch</Btn></div>
          </div>
        ))}
      </div>
    </div>
  );
}
