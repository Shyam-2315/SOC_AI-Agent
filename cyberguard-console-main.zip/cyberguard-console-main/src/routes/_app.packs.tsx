import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/soc/PageHeader";
import { Btn } from "@/components/soc/Btn";
import { MOCK } from "@/lib/mock";
import { Download, Upload, Package } from "lucide-react";

export const Route = createFileRoute("/_app/packs")({
  head: () => ({ meta: [{ title: "Rule Packs — SentinelAI" }] }),
  component: PacksPage,
});

const STARTERS = ["Sigma Core", "AWS Cloud", "Kubernetes", "Microsoft 365"];

function PacksPage() {
  const [packs, setPacks] = useState(MOCK.packs);
  const [importText, setImportText] = useState("");

  function toggle(id: string) {
    setPacks((p) => p.map((x) => (x.id === id ? { ...x, enabled: !x.enabled } : x)));
  }
  function importPack() {
    try {
      const j = JSON.parse(importText || "{}");
      const name = j.name || "Imported pack";
      setPacks((p) => [...p, { id: `p-${Date.now()}`, name, rules: j.rules?.length ?? 0, enabled: true, version: j.version || "0.1.0" }]);
      setImportText("");
    } catch {
      alert("Invalid JSON / YAML");
    }
  }
  function exportPack(id: string) {
    const pack = packs.find((p) => p.id === id);
    const blob = new Blob([JSON.stringify(pack, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `${pack?.name}.json`; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Detection" title="Rule Packs" description="Import, export and toggle Sigma-compatible rule bundles." />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-3">
          {packs.map((p) => (
            <div key={p.id} className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 shadow-card">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary"><Package className="h-5 w-5" /></div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{p.name}</span>
                  <span className="rounded-full border border-border px-2 py-0.5 text-[10px] text-muted-foreground">v{p.version}</span>
                </div>
                <div className="text-xs text-muted-foreground">{p.rules} rules</div>
              </div>
              <button onClick={() => toggle(p.id)} className={`relative h-6 w-11 rounded-full border ${p.enabled ? "border-primary bg-primary/30" : "border-border bg-muted"}`}>
                <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-foreground transition ${p.enabled ? "left-6" : "left-0.5"}`} />
              </button>
              <Btn variant="outline" size="sm" onClick={() => exportPack(p.id)}><Download className="h-4 w-4" /> Export</Btn>
            </div>
          ))}
        </div>

        <div className="space-y-4">
          <div className="rounded-xl border border-border bg-card p-4 shadow-card">
            <div className="mb-2 text-sm font-semibold">Import pack</div>
            <textarea
              value={importText} onChange={(e) => setImportText(e.target.value)}
              placeholder='{"name":"My Pack","version":"1.0.0","rules":[]}'
              rows={6}
              className="w-full rounded-md border border-border bg-background p-3 font-mono text-xs focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
            />
            <Btn className="mt-2 w-full" variant="hero" size="sm" onClick={importPack}><Upload className="h-4 w-4" /> Import JSON / YAML</Btn>
          </div>
          <div className="rounded-xl border border-border bg-card p-4 shadow-card">
            <div className="mb-2 text-sm font-semibold">Starter packs</div>
            <ul className="space-y-1.5 text-sm">
              {STARTERS.map((s) => (
                <li key={s} className="flex items-center justify-between rounded-md border border-border bg-background/50 px-3 py-2">
                  <span>{s}</span>
                  <button className="text-xs text-primary hover:underline" onClick={() => setPacks((p) => [...p, { id: `p-${Date.now()}`, name: s, rules: 50, enabled: true, version: "1.0.0" }])}>Install</button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
