import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ShieldCheck, ArrowRight, Loader2 } from "lucide-react";
import { Btn } from "@/components/soc/Btn";
import { setToken, api, ApiError } from "@/lib/api";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Sign in — SentinelAI" }] }),
  component: Login,
});

const DEMO = { email: "admin@demo.io", password: "demo1234" };

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      const res = await api<{ token: string }>("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      setToken(res.token);
      navigate({ to: "/dashboard" });
    } catch (err) {
      // Backend unreachable or invalid creds: still allow demo login
      if (email === DEMO.email && password === DEMO.password) {
        setToken("demo-token");
        navigate({ to: "/dashboard" });
        return;
      }
      setError(err instanceof ApiError ? err.message : "Could not reach the auth service. Try the demo admin.");
    } finally {
      setBusy(false);
    }
  }

  function useDemo() {
    setEmail(DEMO.email); setPassword(DEMO.password);
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2 bg-gradient-hero">
      <div className="hidden flex-col justify-between border-r border-border bg-card/30 p-10 lg:flex">
        <div className="flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-primary shadow-glow">
            <ShieldCheck className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-semibold">Sentinel<span className="text-primary">AI</span></span>
        </div>
        <div>
          <h2 className="text-3xl font-semibold tracking-tight">Autonomous SOC, in one console.</h2>
          <p className="mt-3 max-w-md text-sm text-muted-foreground">
            Triage, investigate and respond at machine speed. Sentinel fuses detection-as-code with agentic AI to give your analysts superpowers.
          </p>
        </div>
        <div className="text-xs text-muted-foreground">© 2026 SentinelAI</div>
      </div>
      <div className="flex items-center justify-center px-6 py-12">
        <form onSubmit={submit} className="w-full max-w-sm space-y-5 rounded-2xl border border-border bg-card p-7 shadow-card">
          <div className="lg:hidden flex items-center gap-2">
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-primary"><ShieldCheck className="h-4 w-4 text-primary-foreground" /></div>
            <span className="font-semibold">SentinelAI</span>
          </div>
          <div>
            <h1 className="text-xl font-semibold">Sign in</h1>
            <p className="mt-1 text-sm text-muted-foreground">Welcome back. Sign in to your console.</p>
          </div>
          <div className="space-y-3">
            <label className="block">
              <span className="mb-1 block text-xs font-medium text-muted-foreground">Email</span>
              <input
                type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                placeholder="you@company.com"
              />
            </label>
            <label className="block">
              <span className="mb-1 block text-xs font-medium text-muted-foreground">Password</span>
              <input
                type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                placeholder="••••••••"
              />
            </label>
          </div>
          {error && <div className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">{error}</div>}
          <Btn type="submit" variant="hero" size="lg" className="w-full" disabled={busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <>Sign in <ArrowRight className="h-4 w-4" /></>}
          </Btn>
          <div className="rounded-md border border-dashed border-border bg-background/40 p-3 text-xs">
            <div className="mb-1 font-semibold uppercase tracking-wider text-muted-foreground">Demo mode</div>
            <div className="font-mono text-[11px] text-muted-foreground">{DEMO.email} · {DEMO.password}</div>
            <button type="button" onClick={useDemo} className="mt-2 text-primary hover:underline">Use Demo Admin →</button>
          </div>
        </form>
      </div>
    </div>
  );
}
