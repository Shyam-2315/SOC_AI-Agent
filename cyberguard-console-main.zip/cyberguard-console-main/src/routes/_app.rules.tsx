import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/soc/PageHeader";
import { Btn } from "@/components/soc/Btn";
import { SeverityBadge } from "@/components/soc/SeverityBadge";
import { MOCK } from "@/lib/mock";
import { Trash2, Plus, X } from "lucide-react";

export const Route = createFileRoute("/_app/rules")({
  head: () => ({ meta: [{ title: "Detection Rules — SentinelAI" }] }),
  component: RulesPage,
});

type Rule = (typeof MOCK.rules)[number] & { conditions?: { field: string; op: string; value: string }[] };

function RulesPage() {
  const [rules, setRules] = useState<Rule[]>(MOCK.rules.map((r) => ({ ...r, conditions: [{ field: "process.name", op: "equals", value: "powershell.exe" }] })));
  const [editing, setEditing] = useState<Rule | null>(null);

  function toggle(id: string) {
    setRules((p) => p.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r)));
  }
  function remove(id: string) {
    setRules((p) => p.filter((r) => r.id !== id));
  }
  function save(r: Rule) {
    setRules((p) => (p.find((x) => x.id === r.id) ? p.map((x) => (x.id === r.id ? r : x)) : [...p, r]));
    setEditing(null);
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Detection"
        title="Detection Rules"
        description="Sigma-style rules powering streaming detection."
        actions={<Btn variant="hero" size="sm" onClick={() => setEditing({ id: `r-${Date.now()}`, name: "New rule", enabled: true, severity: "medium", description: "", conditions: [{ field: "", op: "equals", value: "" }] })}><Plus className="h-4 w-4" /> New rule</Btn>}
      />
      <div className="grid gap-3">
        {rules.map((r) => (
          <div key={r.id} className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 shadow-card md:flex-row md:items-center">
            <button
              onClick={() => toggle(r.id)}
              className={`relative h-6 w-11 shrink-0 rounded-full border transition ${r.enabled ? "border-primary bg-primary/30" : "border-border bg-muted"}`}
            >
              <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-foreground transition ${r.enabled ? "left-6" : "left-0.5"}`} />
            </button>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="font-medium">{r.name}</span>
                <SeverityBadge severity={r.severity} />
              </div>
              <div className="mt-1 text-xs text-muted-foreground">{r.description}</div>
            </div>
            <div className="flex items-center gap-2">
              <Btn size="sm" variant="outline" onClick={() => setEditing(r)}>Edit</Btn>
              <Btn size="sm" variant="ghost" onClick={() => remove(r.id)} className="text-destructive hover:bg-destructive/10"><Trash2 className="h-4 w-4" /></Btn>
            </div>
          </div>
        ))}
      </div>

      {editing && <RuleEditor rule={editing} onClose={() => setEditing(null)} onSave={save} />}
    </div>
  );
}

function RuleEditor({ rule, onClose, onSave }: { rule: Rule; onClose: () => void; onSave: (r: Rule) => void }) {
  const [r, setR] = useState<Rule>(rule);
  const conds = r.conditions ?? [];
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-background/70 p-4 backdrop-blur">
      <div className="w-full max-w-xl rounded-xl border border-border bg-card shadow-card">
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <div className="text-sm font-semibold">Edit rule</div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </div>
        <div className="space-y-3 p-5">
          <Field label="Name"><input value={r.name} onChange={(e) => setR({ ...r, name: e.target.value })} className="inp" /></Field>
          <Field label="Description"><input value={r.description} onChange={(e) => setR({ ...r, description: e.target.value })} className="inp" /></Field>
          <Field label="Severity">
            <select value={r.severity} onChange={(e) => setR({ ...r, severity: e.target.value as Rule["severity"] })} className="inp">
              {["critical", "high", "medium", "low"].map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </Field>
          <div>
            <div className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Conditions</div>
            <div className="space-y-2">
              {conds.map((c, i) => (
                <div key={i} className="grid grid-cols-[1fr_auto_1fr_auto] gap-2">
                  <input value={c.field} placeholder="field" onChange={(e) => { const n = [...conds]; n[i] = { ...c, field: e.target.value }; setR({ ...r, conditions: n }); }} className="inp" />
                  <select value={c.op} onChange={(e) => { const n = [...conds]; n[i] = { ...c, op: e.target.value }; setR({ ...r, conditions: n }); }} className="inp">
                    {["equals", "contains", "regex", "in"].map((o) => <option key={o}>{o}</option>)}
                  </select>
                  <input value={c.value} placeholder="value" onChange={(e) => { const n = [...conds]; n[i] = { ...c, value: e.target.value }; setR({ ...r, conditions: n }); }} className="inp" />
                  <button onClick={() => setR({ ...r, conditions: conds.filter((_, j) => j !== i) })} className="rounded-md border border-border px-2 text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
                </div>
              ))}
            </div>
            <button onClick={() => setR({ ...r, conditions: [...conds, { field: "", op: "equals", value: "" }] })} className="mt-2 text-xs text-primary hover:underline">+ Add condition</button>
          </div>
        </div>
        <div className="flex justify-end gap-2 border-t border-border px-5 py-3">
          <Btn variant="ghost" size="sm" onClick={onClose}>Cancel</Btn>
          <Btn variant="hero" size="sm" onClick={() => onSave(r)}>Save rule</Btn>
        </div>
      </div>
      <style>{`.inp{width:100%;border:1px solid var(--color-border);background:var(--color-background);padding:0.5rem 0.75rem;font-size:.875rem;border-radius:.375rem}.inp:focus{outline:none;border-color:var(--color-primary);box-shadow:0 0 0 1px var(--color-primary)}`}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-medium text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
